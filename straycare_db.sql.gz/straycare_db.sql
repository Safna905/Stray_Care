-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2023 at 09:34 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `straycare_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `adoption_tb`
--

CREATE TABLE `adoption_tb` (
  `adopt_id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `adopted_on` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adoption_tb`
--

INSERT INTO `adoption_tb` (`adopt_id`, `request_id`, `status`, `adopted_on`) VALUES
(1, 0, '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `adopt_request_tb`
--

CREATE TABLE `adopt_request_tb` (
  `request_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `sent_status` varchar(20) NOT NULL,
  `reply_status` varchar(20) NOT NULL,
  `send_date` date NOT NULL,
  `reply_date` date NOT NULL,
  `recipient_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adopt_request_tb`
--

INSERT INTO `adopt_request_tb` (`request_id`, `sender_id`, `sent_status`, `reply_status`, `send_date`, `reply_date`, `recipient_id`) VALUES
(1, 0, '', '', '0000-00-00', '0000-00-00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `animal_tb`
--

CREATE TABLE `animal_tb` (
  `animal_id` int(11) NOT NULL,
  `description` varchar(300) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `breed` varchar(50) NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `animal_tb`
--

INSERT INTO `animal_tb` (`animal_id`, `description`, `gender`, `type`, `color`, `breed`, `image`) VALUES
(1, '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `authority_login_tb`
--

CREATE TABLE `authority_login_tb` (
  `log_id` int(11) NOT NULL,
  `code` varchar(8) NOT NULL,
  `password` varchar(50) NOT NULL,
  `authority_type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `authority_login_tb`
--

INSERT INTO `authority_login_tb` (`log_id`, `code`, `password`, `authority_type`) VALUES
(1, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `collected_tb`
--

CREATE TABLE `collected_tb` (
  `collect_id` int(11) NOT NULL,
  `animal_id` int(11) NOT NULL,
  `office_id` int(11) NOT NULL,
  `health_cond` varchar(50) NOT NULL,
  `collect_from` varchar(50) NOT NULL,
  `collected_on` date NOT NULL,
  `status` varchar(20) NOT NULL,
  `died_on` date NOT NULL,
  `reason` varchar(20) NOT NULL,
  `adopted_on` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `collected_tb`
--

INSERT INTO `collected_tb` (`collect_id`, `animal_id`, `office_id`, `health_cond`, `collect_from`, `collected_on`, `status`, `died_on`, `reason`, `adopted_on`) VALUES
(1, 0, 0, '$', '$', '0000-00-00', '', '0000-00-00', '', '0000-00-00'),
(2, 0, 0, '$', '$', '0000-00-00', '', '0000-00-00', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `donation_tb`
--

CREATE TABLE `donation_tb` (
  `donate_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donation_tb`
--

INSERT INTO `donation_tb` (`donate_id`, `user_id`, `amount`, `type`) VALUES
(1, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `forest_tb`
--

CREATE TABLE `forest_tb` (
  `forest_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL,
  `ph_no` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `forest_tb`
--

INSERT INTO `forest_tb` (`forest_id`, `login_id`, `email`, `location`, `ph_no`) VALUES
(1, 0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `foster_tb`
--

CREATE TABLE `foster_tb` (
  `foster_id` int(11) NOT NULL,
  `animal_id` int(11) NOT NULL,
  `health_cond` varchar(50) NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `foster_tb`
--

INSERT INTO `foster_tb` (`foster_id`, `animal_id`, `health_cond`, `image`) VALUES
(1, 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `local_govt_tb`
--

CREATE TABLE `local_govt_tb` (
  `lsg_id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `lsg_name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `ph_no` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `local_govt_tb`
--

INSERT INTO `local_govt_tb` (`lsg_id`, `log_id`, `lsg_name`, `type`, `location`, `email`, `ph_no`) VALUES
(1, 0, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `missing_tb`
--

CREATE TABLE `missing_tb` (
  `missing_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `animal_type` varchar(50) NOT NULL,
  `breed` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `health_cond` varchar(50) NOT NULL,
  `color` varchar(20) NOT NULL,
  `lastseen_on` date NOT NULL,
  `report_date` date NOT NULL,
  `image` longblob NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'missing',
  `mob_no` bigint(10) NOT NULL,
  `lastseen_at` varchar(152) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `missing_tb`
--

INSERT INTO `missing_tb` (`missing_id`, `user_id`, `animal_type`, `breed`, `name`, `health_cond`, `color`, `lastseen_on`, `report_date`, `image`, `status`, `mob_no`, `lastseen_at`) VALUES
(1, 0, '', '', '', '$', '', '0000-00-00', '0000-00-00', '', '', 0, ''),
(2, 1, '', 'good ', 'fish', '', 'orange ', '0000-00-00', '2023-06-17', '', 'missing', 87689734, 'kkm'),
(3, 1, '', 'nice', 'goat', '', 'black', '0000-00-00', '2023-06-17', '', 'missing', 36657, 'hukk');

-- --------------------------------------------------------

--
-- Table structure for table `office_tb`
--

CREATE TABLE `office_tb` (
  `office_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `location` varchar(10) NOT NULL,
  `ph_no` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `office_tb`
--

INSERT INTO `office_tb` (`office_id`, `login_id`, `email`, `location`, `ph_no`) VALUES
(1, 0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `police_tb`
--

CREATE TABLE `police_tb` (
  `police_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `station` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `ph_no` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `police_tb`
--

INSERT INTO `police_tb` (`police_id`, `login_id`, `station`, `location`, `ph_no`) VALUES
(1, 0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `registration_tb`
--

CREATE TABLE `registration_tb` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `place` varchar(150) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `log_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration_tb`
--

INSERT INTO `registration_tb` (`id`, `name`, `image`, `place`, `phone`, `log_id`) VALUES
(1, '', '', '', 0, 0),
(2, '', '', '', 0, 0),
(3, '', '', '', 0, 0),
(4, '', '', '', 0, 0),
(5, '', '', '', 0, 0),
(6, 'kudu', '', 'pkd', 0, 0),
(7, '', '', '', 0, 0),
(8, '', '', '', 0, 0),
(9, 'fdfdsf', '', 'fdfd', 0, 0),
(10, 'fdfdsf1', '', 'fdfd4', 0, 2),
(11, 'fdfdsf1', '', 'fdfd4', 4522, 3),
(12, 'ghj', '', 'tbj', 7997, 4);

-- --------------------------------------------------------

--
-- Table structure for table `report_tb`
--

CREATE TABLE `report_tb` (
  `report_id` int(11) NOT NULL,
  `description` varchar(200) NOT NULL,
  `location` varchar(250) NOT NULL,
  `lati` varchar(100) NOT NULL,
  `longi` varchar(100) NOT NULL,
  `reported_date` datetime(6) NOT NULL,
  `image` blob NOT NULL,
  `case_type` varchar(25) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_tb`
--

INSERT INTO `report_tb` (`report_id`, `description`, `location`, `lati`, `longi`, `reported_date`, `image`, `case_type`, `user_id`) VALUES
(1, '', '', '', '', '0000-00-00 00:00:00.000000', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `log_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`log_id`, `email`, `password`) VALUES
(1, '', ''),
(2, 'sdfdsf2', 'dfsdff6'),
(3, 'sdfdsf2', 'dfsdff6'),
(4, 'thi@gmail.com ', 'f6y');

-- --------------------------------------------------------

--
-- Table structure for table `user_tb`
--

CREATE TABLE `user_tb` (
  `user_id` int(11) NOT NULL,
  `log_id` int(11) NOT NULL,
  `name` varchar(15) NOT NULL,
  `age` varchar(5) NOT NULL,
  `address` varchar(50) NOT NULL,
  `ph_no` varchar(10) NOT NULL,
  `email_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_tb`
--

INSERT INTO `user_tb` (`user_id`, `log_id`, `name`, `age`, `address`, `ph_no`, `email_id`) VALUES
(1, 0, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `veterinary_tb`
--

CREATE TABLE `veterinary_tb` (
  `vet_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `center` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `ph_no` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `veterinary_tb`
--

INSERT INTO `veterinary_tb` (`vet_id`, `login_id`, `center`, `location`, `email`, `ph_no`) VALUES
(1, 0, '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adoption_tb`
--
ALTER TABLE `adoption_tb`
  ADD PRIMARY KEY (`adopt_id`);

--
-- Indexes for table `adopt_request_tb`
--
ALTER TABLE `adopt_request_tb`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `animal_tb`
--
ALTER TABLE `animal_tb`
  ADD PRIMARY KEY (`animal_id`);

--
-- Indexes for table `authority_login_tb`
--
ALTER TABLE `authority_login_tb`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `collected_tb`
--
ALTER TABLE `collected_tb`
  ADD PRIMARY KEY (`collect_id`);

--
-- Indexes for table `donation_tb`
--
ALTER TABLE `donation_tb`
  ADD PRIMARY KEY (`donate_id`);

--
-- Indexes for table `forest_tb`
--
ALTER TABLE `forest_tb`
  ADD PRIMARY KEY (`forest_id`);

--
-- Indexes for table `foster_tb`
--
ALTER TABLE `foster_tb`
  ADD PRIMARY KEY (`foster_id`);

--
-- Indexes for table `local_govt_tb`
--
ALTER TABLE `local_govt_tb`
  ADD PRIMARY KEY (`lsg_id`);

--
-- Indexes for table `missing_tb`
--
ALTER TABLE `missing_tb`
  ADD PRIMARY KEY (`missing_id`);

--
-- Indexes for table `office_tb`
--
ALTER TABLE `office_tb`
  ADD PRIMARY KEY (`office_id`);

--
-- Indexes for table `police_tb`
--
ALTER TABLE `police_tb`
  ADD PRIMARY KEY (`police_id`);

--
-- Indexes for table `registration_tb`
--
ALTER TABLE `registration_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `report_tb`
--
ALTER TABLE `report_tb`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `user_tb`
--
ALTER TABLE `user_tb`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `veterinary_tb`
--
ALTER TABLE `veterinary_tb`
  ADD PRIMARY KEY (`vet_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adoption_tb`
--
ALTER TABLE `adoption_tb`
  MODIFY `adopt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `adopt_request_tb`
--
ALTER TABLE `adopt_request_tb`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `animal_tb`
--
ALTER TABLE `animal_tb`
  MODIFY `animal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `authority_login_tb`
--
ALTER TABLE `authority_login_tb`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `collected_tb`
--
ALTER TABLE `collected_tb`
  MODIFY `collect_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `donation_tb`
--
ALTER TABLE `donation_tb`
  MODIFY `donate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `forest_tb`
--
ALTER TABLE `forest_tb`
  MODIFY `forest_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `foster_tb`
--
ALTER TABLE `foster_tb`
  MODIFY `foster_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `local_govt_tb`
--
ALTER TABLE `local_govt_tb`
  MODIFY `lsg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `missing_tb`
--
ALTER TABLE `missing_tb`
  MODIFY `missing_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `office_tb`
--
ALTER TABLE `office_tb`
  MODIFY `office_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `police_tb`
--
ALTER TABLE `police_tb`
  MODIFY `police_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registration_tb`
--
ALTER TABLE `registration_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `report_tb`
--
ALTER TABLE `report_tb`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_tb`
--
ALTER TABLE `user_tb`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `veterinary_tb`
--
ALTER TABLE `veterinary_tb`
  MODIFY `vet_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
